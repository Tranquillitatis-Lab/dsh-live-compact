/**
 * 备份文件。按会话分目录，默认上限 256MB，快满时删最老的。
 * Shadow files live in per-session directories. Default cap is 256MB; delete the oldest when nearly full.
 *
 * 删除顺序：根目录旧文件，死会话，当前会话的旧文件。
 * 不删当前卡片指向的文件，也不删别的还活着的会话。ENOENT 当成已经删掉。
 * Delete legacy root files, then dead sessions, then old files of the current session.
 * Never delete the current card's file or another live session. ENOENT counts as already freed.
 */
import { execFileSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import { homedir } from "node:os";
import { performance } from "node:perf_hooks";
import { workerData } from "node:worker_threads";
import {
  constants as fsConstants,
  chmodSync,
  closeSync,
  existsSync,
  fchmodSync,
  fstatSync,
  fsyncSync,
  linkSync,
  lstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readSync,
  readdirSync,
  realpathSync,
  renameSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import { basename, dirname, join, resolve, win32 } from "node:path";

const DRIVE_ROOT = /^[A-Za-z]:[\\/]/;
const PLUGIN_NAME = /^(?:(?:cut|official|shadow)-\d+-[0-9a-f]{8}|raw-[0-9a-f]{16}|\d+-[0-9a-f]{8}-[0-9a-f]{8}|\d+-[0-9a-f]{8,16})\.txt$/;
let cachedSid = "";
const lockedDirs = new Map();
const lockedFiles = new Map();
// 锁表硬上界（P1-4）：两张表只是"该路径已完成 ACL 收紧"的记忆缓存，不是锁本身；
// 真正的锁是固化在文件/目录上的 DACL（win32）或权限位（其他平台），不受本表影响。
// 淘汰安全性论证：
// 1. 淘汰 ≠ 解锁——条目被淘汰后，下次 tightenShadow 对该路径只是重新执行一次
//    幂等的收紧 runner；runner 失败仍抛 ESHADOWACCESS 并触发 fuse（fail-closed），
//    绝不会把"拿不到锁"变成"绕过锁"。
// 2. 名字一次性不变式——raw 分片名 = sha256(toolCallId) 前 16 hex（raw.js rawName），
//    cut/official/shadow 分片名含随机 hex，staging tmp 名含 randomBytes(8)：
//    名字全局唯一、绝不复用，被淘汰的路径键不会被新文件继承，因此既不会出现
//    "同名新文件误命中旧缓存"，也不会造成同名双重加锁。
// 3. 即便假设发生同名重建，tightenShadow 的缓存命中还需通过 sameAccessEntry 的
//    dev:ino:birthtimeNs 身份比对，身份不同必 miss，旧对象的 ACL 记忆绝不会套到
//    新对象上。
// 正常情况下 rotation 会随删除同步回收条目（见 releaseLockedFile），锁表规模随
// 磁盘存活分片数收敛；本上界 4096 只是兜底（写入失败清理路径等残留）。
const MAX_LOCK_ENTRIES = 4096;
let shadowFuseState = new Int32Array(new SharedArrayBuffer(Int32Array.BYTES_PER_ELEMENT));
const shadowWarnings = new Set();
const DECISION_ROTATION_INTERVAL_MS = 1000;
const decisionRotationAt = new Map();
const decisionUsageBytes = new Map();
const decisionUsageMtime = new Map();

// No shared byte ledger. A positively dead holder leaves an immutable fence:
// recovery enables the original shared scans, never ownership or an estimate.
const ROTATION_LOCK = ".spine-rotation.lock";
const ROTATION_OWNER = ".spine-rotation.owner";
const ROTATION_SHARED = ".spine-rotation.shared";
const ROTATION_RECOVERED = ".spine-rotation.recovered";
const USAGE_MAX_AGE_MS = 60_000;
const rotationOwner = /^[0-9a-f]{48}$/.test(workerData?.spineOwner || "")
  ? workerData.spineOwner
  : randomBytes(24).toString("hex");
let rotationScope = null;
let shadowUsage = null;

export function shadowDirectory(env = process.env) {
  return env.SPINE_SHADOW_DIR || defaultShadowDirectory(env);
}

function defaultShadowDirectory(env = process.env) {
  return join(env.DSH_HOME || join(homedir(), ".dsh"), "compaction-spine", "shadow");
}

function realDirectory(dir) {
  return realpathSync.native(dir);
}

export function directoryIdentity(dir) {
  const info = statSync(dir, { bigint: true });
  if (!info.isDirectory() || info.ino <= 0n) return "";
  return `${info.dev}:${info.ino}`;
}

function coordinationError(cause) {
  const error = new Error("spine: shadow rotation coordination unavailable; backup refused", { cause });
  error.code = "ESHADOWBUSY";
  return error;
}

function touchExclusive(file, body = "") {
  let fd;
  try {
    fd = openSync(file, "wx", 0o600);
    writeFileSync(fd, body);
  } catch (error) {
    if (error?.code !== "EEXIST") throw error;
  } finally {
    if (fd !== undefined) closeSync(fd);
  }
}

function readRotationOwner(file) {
  if (!lstatSync(file).isFile()) throw new Error("shadow owner is not a regular file");
  const fd = openSync(file, "r");
  try {
    const info = fstatSync(fd, { bigint: true });
    if (!info.isFile() || info.size <= 0n || info.size > 256n) throw new Error("invalid shadow owner size");
    const buffer = Buffer.alloc(257);
    const count = readSync(fd, buffer, 0, buffer.length, 0);
    const text = buffer.subarray(0, count).toString("utf8");
    const record = JSON.parse(text);
    if (count !== Number(info.size) || record?.v !== 1 ||
        !Number.isSafeInteger(record.pid) || record.pid <= 0 || record.pid > 0x7fffffff ||
        !/^[0-9a-f]{48}$/.test(record.id) || `${JSON.stringify({ v: 1, pid: record.pid, id: record.id })}\n` !== text) {
      throw new Error("invalid shadow owner record");
    }
    return record;
  } finally {
    closeSync(fd);
  }
}

function rotationOwnerText(record) {
  return `${JSON.stringify({ v: 1, pid: record.pid, id: record.id })}\n`;
}

function publishRotationOwner(file, record) {
  const temp = `${file}.${randomBytes(24).toString("hex")}.tmp`;
  let fd;
  try {
    fd = openSync(temp, "wx", 0o600);
    writeFileSync(fd, rotationOwnerText(record));
    fsyncSync(fd);
    closeSync(fd);
    fd = undefined;
    // The rotation lock serializes owner claims. Remove only the stale owner
    // after its PID was proven dead, then publish the complete replacement.
    try { unlinkSync(file); } catch (error) { if (error?.code !== "ENOENT") throw error; }
    renameSync(temp, file);
  } finally {
    if (fd !== undefined) closeSync(fd);
    try { unlinkSync(temp); } catch {}
  }
}

function ownerProcessAlive(record) {
  try {
    process.kill(record.pid, 0);
    return true;
  } catch (error) {
    return error?.code !== "ESRCH";
  }
}

function claimRotationOwner(file) {
  const next = { pid: process.pid, id: rotationOwner };
  let current;
  try {
    current = readRotationOwner(file);
  } catch (error) {
    if (error?.code !== "ENOENT") return false;
  }
  if (current) {
    if (current.pid === next.pid && current.id === next.id) return true;
    if (ownerProcessAlive(current)) return false;
  }
  try {
    publishRotationOwner(file, next);
    return readRotationOwner(file).pid === next.pid && readRotationOwner(file).id === next.id;
  } catch {
    return false;
  }
}

function rotationRecordText(record) {
  return `${JSON.stringify({ v: 1, pid: record.pid, id: record.id })}\n`;
}

function readRotationRecord(file) {
  // Reject directories (including old empty locks), symlinks and special files
  // before opening. Neither malformed nor oversized metadata proves death.
  if (!lstatSync(file).isFile()) throw new Error("shadow holder is not a regular file");
  const fd = openSync(file, "r");
  try {
    const info = fstatSync(fd, { bigint: true });
    if (!info.isFile() || info.size <= 0n || info.size > 256n) throw new Error("invalid shadow holder size");
    const buffer = Buffer.alloc(257);
    const count = readSync(fd, buffer, 0, buffer.length, 0);
    const text = buffer.subarray(0, count).toString("utf8");
    const record = JSON.parse(text);
    if (count !== Number(info.size) || record?.v !== 1 ||
        !Number.isSafeInteger(record.pid) || record.pid <= 0 || record.pid > 0x7fffffff ||
        !/^[0-9a-f]{48}$/.test(record.id) || rotationRecordText(record) !== text) {
      throw new Error("invalid shadow holder record");
    }
    return { ...record, identity: `${info.dev}:${info.ino}` };
  } finally {
    closeSync(fd);
  }
}

function sameRotationRecord(left, right) {
  return left.pid === right.pid && left.id === right.id;
}

function publishRotationRecord(file, record) {
  const temp = `${file}.${randomBytes(24).toString("hex")}.tmp`;
  let fd;
  let created = false;
  try {
    fd = openSync(temp, "wx", 0o600);
    created = true;
    writeFileSync(fd, rotationRecordText(record));
    fsyncSync(fd);
    const info = fstatSync(fd, { bigint: true });
    const published = { ...record, identity: `${info.dev}:${info.ino}` };
    closeSync(fd);
    fd = undefined;
    // Same-directory hard links atomically publish a complete, closed file on
    // POSIX and Windows. Unlike rename, link never replaces an existing lock.
    try { linkSync(temp, file); } catch (cause) {
      // Only a failure of this operation proves that hardlink publication is
      // unsupported. Permission, I/O and other ambiguous errors stay closed.
      if (!["ENOTSUP", "EOPNOTSUPP", "ENOSYS"].includes(cause?.code)) throw cause;
      const error = new Error("shadow hardlink publication unsupported", { cause });
      error.code = "ESHADOWLINKUNSUPPORTED";
      throw error;
    }
    return published;
  } finally {
    if (fd !== undefined) closeSync(fd);
    // The temp is only an extra name. Cleanup must neither hide publication's
    // outcome nor discard the exact ownership handle of an already live lock.
    if (created) { try { unlinkSync(temp); } catch {} }
  }
}

function syncRotationDirectory(root) {
  // Node cannot open/flush directory handles on Windows. The marker files are
  // flushed there too; POSIX also flushes their directory entries.
  if (process.platform === "win32") return;
  const fd = openSync(root, "r");
  try { fsyncSync(fd); } finally { closeSync(fd); }
}

function persistRotationFence(root, name) {
  const file = join(root, name);
  const fd = openSync(file, "a", 0o600);
  let identity;
  try {
    const info = fstatSync(fd, { bigint: true });
    if (!info.isFile()) throw new Error("invalid shadow fence");
    identity = `${info.dev}:${info.ino}`;
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
  syncRotationDirectory(root);
  return identity;
}

function persistRotationShared(root) {
  return persistRotationFence(root, ROTATION_SHARED);
}

function linklessRecoveryName(record) {
  // An empty file's name atomically records the complete proven-dead token;
  // unlike writing JSON via wx, a crash cannot expose a partial recovery record.
  return `${ROTATION_RECOVERED}-${record.pid}-${record.id}`;
}

function hasLinklessRecovery(root, record) {
  try {
    const info = lstatSync(join(root, linklessRecoveryName(record)));
    if (!info.isFile() || info.size !== 0) throw new Error("invalid shadow recovery fence");
    return true;
  } catch (error) {
    if (error?.code === "ENOENT") return false;
    throw error;
  }
}

function publishLinklessRecovery(root, record) {
  let fd;
  try {
    fd = openSync(join(root, linklessRecoveryName(record)), "wx", 0o600);
  } catch (error) {
    if (error?.code === "EEXIST" && hasLinklessRecovery(root, record)) return;
    throw error;
  }
  try { fsyncSync(fd); } finally { closeSync(fd); }
  if (!hasLinklessRecovery(root, record)) throw new Error("shadow recovery fence disappeared");
}

function verifyRotationGuard(root, identity, guard) {
  if (identity && directoryIdentity(root) !== identity) throw new Error("shadow directory identity changed");
  if (!guard.record) {
    const fence = lstatSync(join(root, ROTATION_SHARED), { bigint: true });
    if (!guard.sharedIdentity || !fence.isFile() || `${fence.dev}:${fence.ino}` !== guard.sharedIdentity) {
      throw new Error("shadow shared fence identity changed");
    }
    try { lstatSync(join(root, ROTATION_LOCK)); } catch (error) {
      if (error?.code === "ENOENT") return;
      throw error;
    }
    throw new Error("shadow transaction appeared during shared fallback");
  }
  const current = readRotationRecord(join(root, ROTATION_LOCK));
  if (!sameRotationRecord(current, guard.record) || current.identity !== guard.record.identity) {
    throw new Error("shadow lock identity changed");
  }
}

function releaseRotationGuard(root, identity, guard) {
  verifyRotationGuard(root, identity, guard);
  if (guard.owned) unlinkSync(join(root, ROTATION_LOCK));
}

function acquireRotationGuard(root, identity) {
  const lock = join(root, ROTATION_LOCK);
  // A host transaction gets a fresh fence token every time. Managed workers
  // keep their stable owner token so a timed-out parent can recover exactly
  // the worker-held lock without touching another transaction.
  const transactionId = workerData?.spineWorker === 1
    ? rotationOwner
    : randomBytes(24).toString("hex");
  const record = { pid: process.pid, id: transactionId };
  let guard;
  try {
    const published = publishRotationRecord(lock, record);
    guard = { owned: true, record: published };
    verifyRotationGuard(root, identity, guard);
    return guard;
  } catch (error) {
    shadowUsage = null;
    if (guard) {
      // Publication succeeded, but acquisition never returned its ownership
      // handle. Retry validation before releasing only that exact root/object/
      // record; a replacement or an unreadable guard must remain untouched.
      try { releaseRotationGuard(root, identity, guard); } catch {}
      throw error;
    }
    if (error?.code === "ESHADOWLINKUNSUPPORTED") {
      // Fence out all future exclusive estimates BEFORE observing a possible
      // earlier transaction. An exclusive owner publishes its lock first, so
      // absence after this durable fence cannot hide an active exclusive scope.
      const sharedIdentity = persistRotationShared(root);
      let observed;
      try { observed = readRotationRecord(lock); } catch (failure) {
        if (failure?.code !== "ENOENT") throw failure;
        const guard = { owned: false, sharedIdentity };
        verifyRotationGuard(root, identity, guard);
        return guard;
      }
      return recoverRotationGuard(root, identity, { owned: false, record: observed });
    }
    try { touchExclusive(join(root, ROTATION_SHARED)); } catch {}
    if (error?.code !== "EEXIST") throw error;
  }

  return recoverRotationGuard(root, identity, { owned: false, record: readRotationRecord(lock) });
}

function recoverRotationGuard(root, identity, guard) {
  const recovered = join(root, ROTATION_RECOVERED);
  let recovery;
  try { recovery = readRotationRecord(recovered); } catch (error) {
    if (error?.code !== "ENOENT") throw error;
  }
  const priorRecovery = recovery && sameRotationRecord(recovery, guard.record);
  const knownDead = priorRecovery || hasLinklessRecovery(root, guard.record);
  if (!knownDead) {
    let dead = false;
    try { process.kill(guard.record.pid, 0); } catch (error) { dead = error?.code === "ESRCH"; }
    if (!dead) {
      if (recovery) {
        throw Object.assign(new Error("shadow recovery identity changed"), { step: "rotation-recovery-conflict" });
      }
      throw new Error("shadow holder is live or its death is unknown");
    }
  }
  // Persist shared participation BEFORE permitting any action or recording
  // recovery. A later reused PID cannot resurrect this exact proven-dead token.
  persistRotationShared(root);
  verifyRotationGuard(root, identity, guard);
  if (!knownDead) {
    if (recovery) {
      publishLinklessRecovery(root, guard.record);
    } else {
      try {
        publishRotationRecord(recovered, guard.record);
      } catch (error) {
        if (error?.code === "ESHADOWLINKUNSUPPORTED" ||
            (error?.code === "EEXIST" && !sameRotationRecord(readRotationRecord(recovered), guard.record))) {
          publishLinklessRecovery(root, guard.record);
        } else if (error?.code !== "EEXIST") {
          throw error;
        }
      }
    }
    syncRotationDirectory(root);
  }
  verifyRotationGuard(root, identity, guard);
  return guard; // Never unlink or replace an observed lock, even after ESRCH.
}

function dedicatedRoot(root, identity) {
  if (!identity || process.env.SPINE_SHADOW_SINGLE_PROCESS !== "1" || !process.env.SPINE_SHADOW_DIR) return false;
  try {
    if (realDirectory(process.env.SPINE_SHADOW_DIR) !== root) return false;
    // Explicitly spelling the normal shared root is not a dedicated-root contract.
    let normal = resolve(defaultShadowDirectory());
    try { normal = realDirectory(normal); } catch (error) {
      if (error?.code !== "ENOENT" && error?.code !== "ENOTDIR") return false;
    }
    return normal !== root;
  } catch {
    return false;
  }
}

// A root is explicit at production call sites. Standalone helpers can also find
// an already participating parent; custom callers must pass root when using a
// session directory outside their configured shadowDirectory().
export function shadowRootForDir(dir) {
  const configured = shadowDirectory();
  try {
    const root = realDirectory(configured);
    let path;
    try { path = realDirectory(dir); } catch {
      path = join(realDirectory(dirname(resolve(dir))), basename(dir));
    }
    if (path === root || dirname(path) === root) return configured;
  } catch {}
  if (existsSync(join(dirname(dir), ROTATION_OWNER)) || existsSync(join(dirname(dir), ROTATION_SHARED))) return dirname(dir);
  return dir;
}

function scopedFile(file, root) {
  const path = join(realDirectory(dirname(file)), basename(file));
  const dir = dirname(path);
  return dir === root || dirname(dir) === root ? path : null;
}

function verifyRotationScope() {
  try {
    verifyRotationGuard(rotationScope.root, rotationScope.identity, rotationScope.guard);
  } catch (error) {
    shadowUsage = null;
    throw coordinationError(error);
  }
}

function retireRotationScope() {
  shadowUsage = null;
  rotationScope.exclusive = false;
  touchExclusive(join(rotationScope.root, ROTATION_SHARED));
}

function rememberShadowParent(dir) {
  const identity = directoryIdentity(dir);
  const expected = rotationScope.parents.get(dir);
  if (expected !== undefined && expected !== identity) {
    retireRotationScope();
    throw coordinationError(new Error("shadow session directory identity changed"));
  }
  rotationScope.parents.set(dir, identity);
  if (!identity && rotationScope.exclusive) retireRotationScope();
  return identity;
}

// Synchronous and reentrant only within this module's current root transaction.
// Different module instances/workers have different random owner tokens and use
// the same filesystem lock, even when they share a PID or a path alias.
export function withShadowRoot(dir, action) {
  let root;
  try { root = realDirectory(dir); } catch (error) { throw coordinationError(error); }
  if (rotationScope) {
    if (rotationScope.root !== root) throw coordinationError(new Error("nested shadow roots"));
    verifyRotationScope();
    return action();
  }
  const shared = join(root, ROTATION_SHARED);
  let identity;
  let guard;
  try {
    identity = directoryIdentity(root);
    guard = acquireRotationGuard(root, identity);
  } catch (error) {
    shadowUsage = null;
    throw coordinationError(error);
  }
  try {
    verifyRotationGuard(root, identity, guard);
    const optedIn = guard.owned && dedicatedRoot(root, identity);
    const owner = join(root, ROTATION_OWNER);
    let token = "";
    let currentOwner;
    try { currentOwner = readRotationOwner(owner); } catch {}
    const ownsCurrent = currentOwner?.pid === process.pid && currentOwner?.id === rotationOwner;
    if (optedIn && !existsSync(shared) && !ownsCurrent) {
      shadowUsage = null;
      if (!claimRotationOwner(owner)) touchExclusive(shared);
    }
    if (existsSync(owner)) {
      try {
        const record = readRotationOwner(owner);
        token = record.pid === process.pid && record.id === rotationOwner ? record.id : "";
      } catch {}
      if (token !== rotationOwner || !optedIn) touchExclusive(shared);
    }
    const exclusive = optedIn && token === rotationOwner && !existsSync(shared);
    if (!exclusive || shadowUsage?.root !== root || shadowUsage?.identity !== identity) shadowUsage = null;
    rotationScope = { root, identity, guard, exclusive, parents: new Map() };
    return action();
  } finally {
    rotationScope = null;
    try {
      releaseRotationGuard(root, identity, guard);
    } catch (error) {
      shadowUsage = null;
      // A transient verification failure must not strand a live owned lock.
      // Retry only with the original handle and the same verification checks.
      if (guard.owned) { try { releaseRotationGuard(root, identity, guard); } catch {} }
      throw coordinationError(error);
    }
  }
}

// Used only after a worker thread has been terminated. The owner token prevents
// a parent from deleting another process's live rotation lock when recovering
// a timed-out worker that shares process.pid with the host.
export function recoverTimedOutShadowWorker(root, owner) {
  try {
    const real = realDirectory(root);
    const lock = join(real, ROTATION_LOCK);
    const record = readRotationRecord(lock);
    if (record.pid !== process.pid || record.id !== owner) return false;
    try { unlinkSync(lock); } catch (error) { if (error?.code !== "ENOENT") return false; }
    const ownerFile = join(real, ROTATION_OWNER);
    try {
      const current = readRotationOwner(ownerFile);
      if (current.pid === process.pid && current.id === owner) unlinkSync(ownerFile);
    } catch (error) {
      if (error?.code !== "ENOENT") return false;
    }
    // Keep the shared fence immutable. It may represent another participant;
    // recovery of this worker must never re-enable an exclusive fast path.
    syncRotationDirectory(real);
    return true;
  } catch {
    return false;
  }
}

export function resetShadowAccessState() {
  cachedSid = "";
  lockedDirs.clear();
  lockedFiles.clear();
  // Test/restart helper only: callers must have no in-flight workers. Keep the
  // same shared buffer so idle worker retirement never creates a new fuse domain.
  Atomics.store(shadowFuseState, 0, 0);
  shadowWarnings.clear();
}

// 记录锁表条目；超过硬上界时按插入序淘汰最旧条目。Map 迭代保持插入序，对已存在
// 键重复 set 不会改变其位置也不增长表，因此每次新插入至多淘汰一条。安全性论证
// 见 MAX_LOCK_ENTRIES 处注释：淘汰只是放弃"免重跑收紧"的记忆，不是解锁。
function rememberLockedEntry(map, key, value) {
  map.set(key, value);
  while (map.size > MAX_LOCK_ENTRIES) {
    const oldest = map.keys().next();
    if (oldest.done) break;
    map.delete(oldest.value);
  }
}

// rotation/清理删除文件后同步释放其锁表条目，使锁表随分片删除收敛。键与
// accessEntry 的 canonical 规则一致：真实父目录 + 文件名。父目录已消失时算不出
// canonical 键，留待硬上界兜底；对不存在的键 delete 是无害空操作。
function releaseLockedFile(path) {
  try {
    lockedFiles.delete(join(realDirectory(dirname(path)), basename(path)));
  } catch {}
}

export function shadowAccessFused() {
  return Atomics.load(shadowFuseState, 0) !== 0;
}

export function shadowAccessFuseBuffer() {
  return shadowFuseState.buffer;
}

export function attachShadowAccessFuse(buffer) {
  if (!(buffer instanceof SharedArrayBuffer) || buffer.byteLength !== Int32Array.BYTES_PER_ELEMENT) {
    throw new TypeError("spine: invalid shared shadow access fuse");
  }
  const alreadyFused = shadowAccessFused();
  shadowFuseState = new Int32Array(buffer);
  if (alreadyFused) Atomics.store(shadowFuseState, 0, 1);
}

function tripFuse() {
  Atomics.store(shadowFuseState, 0, 1);
}

function envValue(env, name) {
  if (!env) return "";
  const found = Object.keys(env).find((key) => key.toLowerCase() === name.toLowerCase());
  return found ? String(env[found] ?? "").trim() : "";
}

export function windowsSystemRoot(env = process.env) {
  const systemRoot = envValue(env, "SystemRoot");
  const windir = envValue(env, "windir");
  const root = (DRIVE_ROOT.test(systemRoot) ? systemRoot : "") || (DRIVE_ROOT.test(windir) ? windir : "");
  return root.replace(/[\\/]+$/, "");
}

export function win32Tool(name, env = process.env) {
  const root = windowsSystemRoot(env);
  if (!root) {
    const error = new Error("spine: Windows system root is not a drive path");
    error.code = "ESHADOWACCESS";
    throw error;
  }
  return win32.join(root, "System32", name);
}

function accessIdentity(info) {
  if (info.ino <= 0n) return "";
  return `${info.dev}:${info.ino}:${info.birthtimeNs}`;
}

function accessEntry(path, kind) {
  const absolute = resolve(path);
  // Directory aliases are supported, but cached aliases must keep pointing to
  // the same object. Never follow a final file symlink or chmod a hard link.
  const canonical = kind === "dir" ? realDirectory(absolute) : join(realDirectory(dirname(absolute)), basename(absolute));
  const info = lstatSync(canonical, { bigint: true });
  if (kind === "dir" ? !info.isDirectory() : !info.isFile() || info.nlink !== 1n) {
    throw new Error("spine: unsupported shadow permission target");
  }
  return { absolute, canonical, identity: accessIdentity(info), mode: info.mode };
}

function sameAccessEntry(left, right) {
  return left.canonical === right.canonical && left.identity && left.identity === right.identity;
}

function lockedDirectory(entry) {
  const previous = lockedDirs.get(entry.absolute) ?? lockedDirs.get(entry.canonical);
  if (!previous) return false;
  if (!sameAccessEntry(previous, entry)) throw new Error("spine: shadow permission directory identity changed");
  rememberLockedEntry(lockedDirs, entry.absolute, previous);
  return true;
}

export function shadowDirLocked(path) {
  return lockedDirectory(accessEntry(path, "dir"));
}

export function noteShadowWarning(logger, error) {
  const code = error?.code || "ESHADOWACCESS";
  const step = error?.step || error?.cause?.step || "";
  const separateReason = step === "rotation-recovery-conflict" || step === "dir-mode" || step === "file-mode";
  const key = separateReason ? `${code}:${step}` : code;
  if (shadowWarnings.has(key)) return;
  shadowWarnings.add(key);
  const status = error?.cause?.status ?? error?.status;
  const where = step ? ` ${step}` : "";
  const exit = status == null ? "" : ` exit ${status}`;
  logger?.warn?.(`spine: shadow permission failed ${code}${where}${exit}`);
}
const SESSION_MARK = /^# spine-session (\S+)/;

export function isPluginShadowName(name) {
  return name === "spine-decisions.jsonl" || PLUGIN_NAME.test(name);
}

export function sanitizeSessionKey(key) {
  const safe = String(key || "default").replace(/[^A-Za-z0-9_-]/g, "");
  return safe || "default";
}

export function sessionDir(root, key) {
  return join(root, sanitizeSessionKey(key));
}

function ownerPid(dir) {
  try {
    const text = readFileSync(join(dir, "owner"), "utf8").trim();
    const pid = Number(text);
    return /^[1-9]\d*$/.test(text) && Number.isSafeInteger(pid) ? pid : null;
  } catch (error) {
    return error?.code === "ENOENT" ? 0 : null;
  }
}

function processAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code !== "ESRCH";
  }
}

export function shadowFileBody(sessionKey, body) {
  const key = String(sessionKey || "default").replace(/\s+/g, "");
  return `# spine-session ${key}\n${body || ""}`;
}

export const STATS_NAME = "spine-stats.json";
export const CUTS_NAME = "spine-cuts.jsonl";
export const DECISIONS_NAME = "spine-decisions.jsonl";
export const MAINTENANCE_NAME = "spine-maintenance.jsonl";
const CUTS_LOG_MAX_BYTES = 1024 * 1024;
const MAINTENANCE_LOG_MAX_BYTES = 256 * 1024;

export function appendDecision(dir, record = {}, { protectPaths = [] } = {}) {
  try {
    if (!existsSync(dir)) return false;
    const body = `${JSON.stringify({
      v: 1,
      ts: new Date().toISOString(),
      ...record,
    })}\n`;
    const file = join(dir, DECISIONS_NAME);
    return withShadowRoot(dir, () => {
      const path = scopedFile(file, rotationScope.root);
      if (!path) throw coordinationError(new Error("shadow decision outside root scope"));
      const rotationKey = rotationScope.root;
      const now = Date.now();
      const lastRotation = decisionRotationAt.get(rotationKey) || 0;
      const incomingBytes = Buffer.byteLength(body, "utf8");
      const cap = shadowMaxBytes();
      let knownUsage = decisionUsageBytes.get(rotationKey);
      let rootMtime = null;
      try { rootMtime = statSync(rotationKey).mtimeMs; } catch {}
      const knownMtime = decisionUsageMtime.get(rotationKey);
      const fastPath = rotationScope.exclusive && shadowUsage?.root === rotationKey &&
        shadowUsage?.identity === rotationScope.identity &&
        now - lastRotation < DECISION_ROTATION_INTERVAL_MS &&
        Number.isSafeInteger(knownUsage) && rootMtime !== null && knownMtime === rootMtime;
      if (!fastPath) {
        const rotation = rotateShadowLocked({
          incomingBytes,
          protectPath: path,
          protectPaths,
          sessionKey: record.sid || record.sessionId || "default",
          cap,
        });
        if (!rotation.ok || rotation.oversize) return false;
        decisionRotationAt.set(rotationKey, now);
        knownUsage = rotation.used;
        decisionUsageBytes.set(rotationKey, knownUsage);
        try { decisionUsageMtime.set(rotationKey, statSync(rotationKey).mtimeMs); } catch {}
      } else if (Number.isSafeInteger(knownUsage) && knownUsage + incomingBytes > cap) {
        return false;
      }
      if (existsSync(path)) {
        const beforeOpen = lstatSync(path, { bigint: true });
        if (!beforeOpen.isFile() || beforeOpen.nlink !== 1n) {
          throw coordinationError(new Error("shadow decision is not a single-link regular file"));
        }
        const noFollow = fsConstants.O_NOFOLLOW;
        const fd = openSync(path, fsConstants.O_WRONLY | fsConstants.O_APPEND | (noFollow ?? 0));
        try {
          const opened = fstatSync(fd, { bigint: true });
          const named = lstatSync(path, { bigint: true });
          if (!opened.isFile() || opened.nlink !== 1n || !named.isFile() || named.nlink !== 1n ||
              opened.dev !== named.dev || opened.ino !== named.ino) {
            throw coordinationError(new Error("shadow decision identity changed"));
          }
          writeFileSync(fd, body);
          fsyncSync(fd);
        } finally {
          closeSync(fd);
        }
        if (shadowUsage && isPluginShadowName(basename(path))) {
          shadowUsage.bytes += Buffer.byteLength(body, "utf8");
        }
        decisionUsageBytes.set(rotationKey, (knownUsage ?? 0) + incomingBytes);
        if (rootMtime !== null) decisionUsageMtime.set(rotationKey, rootMtime);
      } else {
        writeShadowFileLocked(path, body, {}, {
          exclusive: false,
          write: writeFileSync,
          unlink: unlinkSync,
          accessPath: file,
        });
        decisionUsageBytes.set(rotationKey, (knownUsage ?? 0) + incomingBytes);
        if (rootMtime !== null) decisionUsageMtime.set(rotationKey, rootMtime);
      }
      return true;
    });
  } catch {
    return false;
  }
}

export function readCutStats(dir) {
  try {
    const parsed = JSON.parse(readFileSync(join(dir, STATS_NAME), "utf8"));
    return {
      cuts: Number(parsed.cuts) || 0,
      savedTokens: Number(parsed.savedTokens) || 0,
      rewriteTokens: Number(parsed.rewriteTokens) || 0,
      drains: Number(parsed.drains) || 0,
    };
  } catch {
    return { cuts: 0, savedTokens: 0, rewriteTokens: 0, drains: 0 };
  }
}

export function drainRewrite(notes) {
  const cuts = (notes || []).filter((note) => note?.kind === "cut" && note.saved > 0);
  if (!cuts.length) return 0;
  const later = cuts.slice(1).reduce((sum, note) => sum + (note.saved || 0), 0);
  return Math.max(0, (cuts[0].afterPrefix || 0) - later);
}

function acquireStatsLock(lock) {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    let fd;
    let created = false;
    try {
      fd = openSync(lock, "wx", 0o600);
      created = true;
      writeFileSync(fd, String(process.pid));
      fsyncSync(fd);
      return fd;
    } catch (error) {
      if (fd !== undefined) {
        try { closeSync(fd); } catch {}
      }
      if (created) {
        try { unlinkSync(lock); } catch {}
      }
      if (error?.code !== "EEXIST") return null;
      let pid = null;
      let observedText = "";
      let observedStat;
      try {
        observedText = readFileSync(lock, "utf8").trim();
        pid = /^[1-9]\d*$/.test(observedText) ? Number(observedText) : null;
        observedStat = statSync(lock);
      } catch {
        return null;
      }
      const dead = pid !== null && processAlive(pid) === false;
      // Pre-1.1.12 locks were empty files. Only recover one that is old enough
      // to be a legacy crash artifact; a just-created empty lock may still be
      // between open(wx) and its PID write.
      const legacyEmpty = observedText === "" && Number.isFinite(observedStat?.mtimeMs) &&
        Date.now() - observedStat.mtimeMs >= 1000;
      if (dead || legacyEmpty) {
        const recovery = `${lock}.recover`;
        let recoveryFd;
        let removed = false;
        try {
          recoveryFd = openSync(recovery, "wx", 0o600);
          writeFileSync(recoveryFd, String(process.pid));
          fsyncSync(recoveryFd);
        } catch (recoveryError) {
          if (recoveryFd !== undefined) {
            try { closeSync(recoveryFd); } catch {}
            try { unlinkSync(recovery); } catch {}
          }
          if (recoveryError?.code === "EEXIST") {
            let recoveryPid = null;
            try {
              const text = readFileSync(recovery, "utf8").trim();
              recoveryPid = /^[1-9]\d*$/.test(text) ? Number(text) : null;
            } catch {}
            if (recoveryPid !== null && processAlive(recoveryPid) === false) {
              try { unlinkSync(recovery); } catch {}
              continue;
            }
          }
          return null;
        }
        try {
          let current = "";
          let currentStat;
          try {
            current = readFileSync(lock, "utf8").trim();
            currentStat = statSync(lock);
          } catch {}
          const unchanged = current === observedText && currentStat && observedStat &&
            currentStat.dev === observedStat.dev && currentStat.ino === observedStat.ino &&
            currentStat.size === observedStat.size && currentStat.mtimeMs === observedStat.mtimeMs;
          if (unchanged && (dead || legacyEmpty)) {
            try { unlinkSync(lock); removed = true; } catch {}
          }
        } finally {
          try { closeSync(recoveryFd); } catch {}
          try { unlinkSync(recovery); } catch {}
        }
        if (removed) continue;
      }
      return null;
    }
  }
  return null;
}

function withCutStatsLock(dir, action) {
  const lock = join(dir, "spine-stats.lock");
  const fd = acquireStatsLock(lock);
  if (fd === null) return null;
  try {
    return action();
  } catch {
    return null;
  } finally {
    try { closeSync(fd); } catch {}
    try { unlinkSync(lock); } catch {}
  }
}

function completeLogSuffix(bytes, discardFirst) {
  const first = discardFirst ? bytes.indexOf(0x0a) + 1 : 0;
  const end = bytes.lastIndexOf(0x0a) + 1;
  if ((discardFirst && !first) || end <= first) return Buffer.alloc(0);
  return bytes.subarray(first, end);
}

function logSuffix(fd, size, budget) {
  // Include one byte before the retained range to recognize an exact line boundary.
  const offset = Math.max(0, size - budget - 1);
  const bytes = Buffer.alloc(size - offset);
  let read = 0;
  while (read < bytes.length) {
    const count = readSync(fd, bytes, read, bytes.length - read, offset + read);
    if (!count) break;
    read += count;
  }
  return completeLogSuffix(bytes.subarray(0, read), size > budget);
}

function verifyLogFile(file, observed) {
  const named = lstatSync(file, { bigint: true });
  if (!named.isFile() || named.nlink !== 1n || !observed.isFile() || observed.nlink !== 1n ||
      !accessIdentity(named) || accessIdentity(named) !== accessIdentity(observed) ||
      named.size !== observed.size || named.mtimeNs !== observed.mtimeNs || named.ctimeNs !== observed.ctimeNs) {
    throw new Error("spine: log identity changed");
  }
}

function replaceLog(file, observed, retained, incoming) {
  const tmp = `${file}.${process.pid}-${randomBytes(8).toString("hex")}.tmp`;
  const fd = openSync(tmp, "wx", 0o600);
  try {
    try {
      writeFileSync(fd, Buffer.concat([retained, incoming]));
      fsyncSync(fd);
    } finally {
      closeSync(fd);
    }
    verifyLogFile(file, observed);
    renameSync(tmp, file);
  } finally {
    try { unlinkSync(tmp); } catch {}
  }
}

function appendBoundedLog(file, body, maxBytes) {
  const bytes = Buffer.from(body);
  const incoming = bytes.length <= maxBytes
    ? bytes
    : completeLogSuffix(bytes.subarray(bytes.length - maxBytes - 1), true);
  let before;
  try {
    before = lstatSync(file, { bigint: true });
  } catch (error) {
    if (error?.code !== "ENOENT") throw error;
    if (incoming.length) writeFileSync(file, incoming, { flag: "wx", mode: 0o600 });
    return;
  }
  if (!before.isFile() || before.nlink !== 1n) throw new Error("spine: unsupported log target");
  const fd = openSync(file, fsConstants.O_RDWR | fsConstants.O_APPEND | (fsConstants.O_NOFOLLOW ?? 0));
  let observed;
  let retained;
  try {
    observed = fstatSync(fd, { bigint: true });
    verifyLogFile(file, before);
    verifyLogFile(file, observed);
    const size = Number(observed.size);
    if (!Number.isSafeInteger(size)) throw new Error("spine: invalid log size");
    const last = Buffer.alloc(1);
    const complete = size === 0 || (readSync(fd, last, 0, 1, size - 1) === 1 && last[0] === 0x0a);
    if (complete && size + incoming.length <= maxBytes) {
      if (incoming.length) writeFileSync(fd, incoming);
      return;
    }
    retained = logSuffix(fd, size, maxBytes - incoming.length);
  } finally {
    closeSync(fd);
  }
  replaceLog(file, observed, retained, incoming);
}

export function appendMaintenanceStatus(dir, record) {
  try {
    if (!existsSync(dir)) return false;
    const root = ensureShadowDirIdentity(dir);
    return withCutStatsLock(dir, () => {
      if (!root || directoryIdentity(dir) !== root) return false;
      const line = JSON.stringify({ v: 1, ts: new Date().toISOString(), ...record });
      appendBoundedLog(join(dir, MAINTENANCE_NAME), `${line}\n`, MAINTENANCE_LOG_MAX_BYTES);
      return true;
    }) === true;
  } catch {
    return false;
  }
}

function writeCutStats(dir, next) {
  const file = join(dir, STATS_NAME);
  const tmp = `${file}.${process.pid}-${randomBytes(8).toString("hex")}.tmp`;
  try {
    writeFileSync(tmp, JSON.stringify(next));
    renameSync(tmp, file);
    return next;
  } finally {
    try { unlinkSync(tmp); } catch {}
  }
}

export function flushDrainStats(dir, notes, meta = {}) {
  const cuts = (notes || []).filter((note) => note?.kind === "cut" && note.saved > 0);
  const charged = drainRewrite(notes);
  const saved = cuts.reduce((sum, note) => sum + note.saved, 0);
  const firstCut = (notes || []).findIndex((note) => note?.kind === "cut");
  const lines = (notes || []).map((note, index) => JSON.stringify({
    v: 1,
    ts: new Date().toISOString(),
    sid: meta.sid || "",
    kind: note.kind || "cut",
    pass: index,
    drain: meta.drain === true,
    saved: note.saved || 0,
    rewriteCharged: index === firstCut ? charged : 0,
    tailBeyondKept: note.tailBeyondKept || 0,
    prefix: note.prefix || 0,
    afterPrefix: note.afterPrefix || 0,
    tokens: note.tokens || 0,
    total: note.total || 0,
    gate: note.gate || "cut",
  }));
  if (!lines.length) return charged;
  withCutStatsLock(dir, () => {
    if (cuts.length) {
      try {
        const prev = readCutStats(dir);
        writeCutStats(dir, {
          cuts: prev.cuts + cuts.length,
          savedTokens: prev.savedTokens + saved,
          rewriteTokens: prev.rewriteTokens + charged,
          drains: prev.drains + 1,
          updatedAt: new Date().toISOString(),
        });
      } catch {}
    }
    try { appendBoundedLog(join(dir, CUTS_NAME), `${lines.join("\n")}\n`, CUTS_LOG_MAX_BYTES); } catch {}
  });
  return charged;
}

export function recordCutStats(dir, { saved = 0, rewrite = 0 } = {}) {
  if (!(saved > 0)) return readCutStats(dir);
  return withCutStatsLock(dir, () => {
    const prev = readCutStats(dir);
    return writeCutStats(dir, {
      cuts: prev.cuts + 1,
      savedTokens: prev.savedTokens + saved,
      rewriteTokens: prev.rewriteTokens + rewrite,
      updatedAt: new Date().toISOString(),
    });
  });
}

function validWindowsSid(sid) {
  if (typeof sid !== "string" || sid.length > 184 || sid.trim() !== sid ||
      !/^S-1-(?:0|[1-9]\d*)(?:-(?:0|[1-9]\d*)){1,15}$/.test(sid)) return false;
  const numbers = sid.slice(4).split("-").map(BigInt);
  return numbers[0] <= 0xffffffffffffn && numbers.slice(1).every((number) => number <= 0xffffffffn);
}

// Fixed code only: path/SID/kind are process environment DATA, never PowerShell
// source or command-line fragments. Full .NET Framework is supplied by the fixed
// System32 WindowsPowerShell v1.0 executable (Windows PowerShell 5.1).
const WINDOWS_ACL_SCRIPT = `
$ErrorActionPreference = 'Stop'
try {
  $path = [Environment]::GetEnvironmentVariable('DSH_SHADOW_ACL_PATH', 'Process')
  $kind = [Environment]::GetEnvironmentVariable('DSH_SHADOW_ACL_KIND', 'Process')
  $sidText = [Environment]::GetEnvironmentVariable('DSH_SHADOW_ACL_SID', 'Process')
  if ([String]::IsNullOrEmpty($path) -or ($kind -ne 'dir' -and $kind -ne 'file')) { throw 'Invalid target' }
  $userSid = [Security.Principal.SecurityIdentifier]::new($sidText)
  if ($userSid.Value -cne $sidText -or [Security.Principal.WindowsIdentity]::GetCurrent().User.Value -cne $sidText) { throw 'Invalid identity' }
  $attributes = [IO.File]::GetAttributes($path)
  if (($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Reparse target' }
  if ((($attributes -band [IO.FileAttributes]::Directory) -ne 0) -ne ($kind -eq 'dir')) { throw 'Wrong target kind' }
  $sids = @($sidText, 'S-1-5-18', 'S-1-5-32-544')
  $expected = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
  $inheritance = [Security.AccessControl.InheritanceFlags]::None
  if ($kind -eq 'dir') {
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $inheritance = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit
  } else {
    $acl = [Security.AccessControl.FileSecurity]::new()
  }
  # A NEW descriptor, not GetAccessControl + grant replacement: no old explicit
  # grant or deny can survive. Only Access is modified; owner/group/SACL are not.
  $acl.SetAccessRuleProtection($true, $false)
  foreach ($sid in $sids) {
    if ($expected.Add($sid)) {
      $rule = [Security.AccessControl.FileSystemAccessRule]::new(
        [Security.Principal.SecurityIdentifier]::new($sid),
        [Security.AccessControl.FileSystemRights]::FullControl,
        $inheritance, [Security.AccessControl.PropagationFlags]::None,
        [Security.AccessControl.AccessControlType]::Allow)
      $acl.AddAccessRule($rule)
    }
  }
  if ($kind -eq 'dir') {
    [IO.Directory]::SetAccessControl($path, $acl)
    $actual = [IO.Directory]::GetAccessControl($path, [Security.AccessControl.AccessControlSections]::Access)
  } else {
    [IO.File]::SetAccessControl($path, $acl)
    $actual = [IO.File]::GetAccessControl($path, [Security.AccessControl.AccessControlSections]::Access)
  }
  if (!$actual.AreAccessRulesProtected -or !$actual.AreAccessRulesCanonical) { throw 'Unprotected DACL' }
  $rules = $actual.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier])
  if ($rules.Count -ne $expected.Count) { throw 'Unexpected ACE count' }
  foreach ($rule in $rules) {
    if (!$expected.Remove($rule.IdentityReference.Value) -or $rule.IsInherited -or
        $rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or
        $rule.FileSystemRights -ne [Security.AccessControl.FileSystemRights]::FullControl -or
        $rule.InheritanceFlags -ne $inheritance -or
        $rule.PropagationFlags -ne [Security.AccessControl.PropagationFlags]::None) { throw 'Unexpected ACE' }
  }
  if ($expected.Count -ne 0) { throw 'Missing ACE' }
  [Console]::Out.Write('DSH_SHADOW_ACL_OK')
  exit 0
} catch {
  # Never echo paths, identity output, or exception data into host logs.
  exit 1
}
`;

export function shadowAccessPlan(platform = process.platform, userSid = "", kind = "dir") {
  if (platform === "win32") {
    if (!validWindowsSid(userSid)) {
      throw new Error("spine: current Windows user SID is required");
    }
    if (kind !== "dir" && kind !== "file") throw new Error("spine: invalid shadow permission kind");

    return {
      kind: "acl",
      usesChmodOnly: false,
      replace: true,
      protected: true,
      inheritance: kind === "dir" ? ["ObjectInherit", "ContainerInherit"] : [],
      allow: [...new Set([userSid, "S-1-5-18", "S-1-5-32-544"])],
      rights: "FullControl",
    };
  }

  return {
    kind: "mode",
    usesChmodOnly: true,
    dirMode: 0o700,
    fileMode: 0o600,
  };
}

function verifyPosixShadowMode(mode, expected, kind) {
  if ((mode & 0o777n) !== BigInt(expected)) {
    const actual = (mode & 0o777n).toString(8).padStart(4, "0");
    const error = new Error(`spine: shadow ${kind} mode ${actual} did not match ${expected.toString(8).padStart(4, "0")}`);
    error.step = `${kind}-mode`;
    throw error;
  }
}

export function defaultShadowAccessRunner({
  path,
  kind,
  platform,
  execFile = execFileSync,
  env = process.env,
} = {}) {
  if (platform !== "win32") {
    const plan = shadowAccessPlan(platform);
    const expected = kind === "dir" ? plan.dirMode : plan.fileMode;
    const before = accessEntry(path, kind);
    chmodSync(before.canonical, expected);
    const after = accessEntry(path, kind);
    if (!sameAccessEntry(before, after)) {
      throw new Error("spine: shadow permission target identity changed");
    }
    verifyPosixShadowMode(after.mode, expected, kind);
    return true;
  }

  if (shadowAccessFused()) {
    const error = new Error("spine: shadow permission already failed");
    error.code = "ESHADOWACCESS";
    throw error;
  }

  let whoamiPath = "";
  let powershellPath = "";
  try {
    whoamiPath = win32Tool("whoami.exe", env);
    powershellPath = win32Tool("WindowsPowerShell\\v1.0\\powershell.exe", env);
  } catch (error) {
    tripFuse();
    throw error;
  }

  let sid = cachedSid;
  if (!sid) {
    let identity = "";
    try {
      identity = execFile(whoamiPath, ["/user", "/fo", "csv", "/nh"], {
        encoding: "utf8",
        windowsHide: true,
        timeout: 10000,
        maxBuffer: 65536,
      });
    } catch (error) {
      error.step = "whoami";
      tripFuse();
      throw error;
    }
    const match = String(identity ?? "").match(/^"(?:[^"\r\n]|"")*","(S-1-[\d-]+)"\s*$/);
    if (!match || !validWindowsSid(match[1])) {
      const error = new Error("spine: cannot determine current Windows user SID");
      error.step = "whoami";
      tripFuse();
      throw error;
    }
    sid = match[1];
    cachedSid = sid;
  }

  try {
    shadowAccessPlan("win32", sid, kind);
    const before = accessEntry(path, kind);
    // Also guard direct runner callers, including legacy files through aliases.
    lockedDirectory(kind === "dir" ? before : accessEntry(dirname(path), "dir"));
    const childEnv = Object.fromEntries(Object.entries(env).filter(([key]) =>
      !/^DSH_SHADOW_ACL_(PATH|KIND|SID)$/i.test(key)));
    Object.assign(childEnv, {
      DSH_SHADOW_ACL_PATH: before.canonical,
      DSH_SHADOW_ACL_KIND: kind,
      DSH_SHADOW_ACL_SID: sid,
    });
    const result = execFile(
      powershellPath,
      // Issue #67 reported a build that rejects -EncodedCommand after whoami.
      ["-NoLogo", "-NoProfile", "-NonInteractive", "-Command", WINDOWS_ACL_SCRIPT],
      { env: childEnv, encoding: "utf8", stdio: "pipe", windowsHide: true, timeout: 15000, maxBuffer: 65536 },
    );
    if (String(result).trim() !== "DSH_SHADOW_ACL_OK") throw new Error("spine: shadow DACL verification not confirmed");
    const after = accessEntry(path, kind);
    if (!sameAccessEntry(before, after)) throw new Error("spine: shadow permission target identity changed");
    if (kind === "dir") {
      rememberLockedEntry(lockedDirs, after.absolute, after);
      rememberLockedEntry(lockedDirs, after.canonical, after);
    } else {
      rememberLockedEntry(lockedFiles, after.canonical, after);
    }
  } catch (error) {
    error.step = kind === "file" ? "file" : "dir";
    tripFuse();
    throw error;
  }

  return true;
}

export function tightenShadow(path, kind = "dir", access = {}) {
  const platform = access.platform ?? process.platform;
  const windows = platform === "win32" && !access.runner;
  if (windows && shadowAccessFused()) {
    const error = new Error("spine: shadow permission action failed; backup refused");
    error.code = "ESHADOWACCESS";
    throw error;
  }

  const runner = access.runner ?? ((action) => defaultShadowAccessRunner({
    ...action,
    execFile: access.execFile,
    env: access.env,
  }));

  try {
    if (windows) {
      if (kind === "dir" && shadowDirLocked(path)) return;
      if (kind === "file") {
        const parentLocked = shadowDirLocked(dirname(path));
        const current = accessEntry(path, kind);
        // A cached parent alone says nothing about an old file's explicit ACEs.
        const previous = lockedFiles.get(current.canonical);
        if (previous && sameAccessEntry(previous, current) && parentLocked) return;
      }
    }
    if (runner({ path, kind, platform, env: access.env, execFile: access.execFile }) !== true) {
      throw new Error("permission runner did not confirm success");
    }
  } catch (cause) {
    if (windows) tripFuse();
    const error = new Error(
      "spine: shadow permission action failed; backup refused",
      { cause },
    );
    error.code = "ESHADOWACCESS";
    error.step = cause?.step;
    throw error;
  }
}

export function ensureShadowDir(dir, access = {}) {
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  tightenShadow(dir, "dir", access);
  return dir;
}

export function ensureShadowDirIdentity(dir, access = {}) {
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  const identity = directoryIdentity(dir);
  tightenShadow(dir, "dir", access);
  if (identity && directoryIdentity(dir) !== identity) {
    throw Object.assign(new Error("spine: shadow directory identity changed"), { code: "ESHADOWACCESS", step: "dir" });
  }
  return identity;
}

function openedShadowEntry(file, fd) {
  const entry = accessEntry(file, "file");
  const opened = fstatSync(fd, { bigint: true });
  if (!opened.isFile() || opened.nlink !== 1n || !entry.identity || entry.identity !== accessIdentity(opened)) {
    throw new Error("spine: shadow created file identity changed");
  }
  return { entry, mode: opened.mode };
}

export function shadowFileIdentity(file, fd) {
  try {
    return fd === undefined ? accessEntry(file, "file").identity : openedShadowEntry(file, fd).entry.identity;
  } catch {
    return "";
  }
}

export function tightenCreatedShadow(file, fd, access = {}, { remember = true, skipRunner = false } = {}) {
  const platform = access.platform ?? process.platform;
  const windows = platform === "win32" && !access.runner;
  const nativePosix = platform !== "win32" && !access.runner;
  try {
    // Only a file created under an already verified Windows parent inherits its DACL.
    const inherited = windows && !skipRunner && !shadowAccessFused() && shadowDirLocked(dirname(file));
    if (!skipRunner && !nativePosix && !inherited) tightenShadow(file, "file", access);
    const plan = nativePosix ? shadowAccessPlan(platform) : null;
    if (plan && !skipRunner) {
      openedShadowEntry(file, fd);
      fchmodSync(fd, plan.fileMode);
    }
    const { entry, mode } = openedShadowEntry(file, fd);
    if (plan) {
      verifyPosixShadowMode(mode, plan.fileMode, "file");
      verifyPosixShadowMode(accessEntry(dirname(file), "dir").mode, plan.dirMode, "dir");
    }
    if (remember && (skipRunner || inherited)) rememberLockedEntry(lockedFiles, entry.canonical, entry);
    return entry.identity;
  } catch (cause) {
    if (cause?.code === "ESHADOWACCESS") throw cause;
    if (windows) tripFuse();
    const error = new Error("spine: shadow permission action failed; backup refused", { cause });
    error.code = "ESHADOWACCESS";
    error.step = cause?.step || "file";
    throw error;
  }
}

export function discardShadowFiles(files, cause, unlink = unlinkSync) {
  const errors = [];

  for (const file of files) {
    if (rotationScope) {
      verifyRotationScope();
      const path = scopedFile(file, rotationScope.root);
      if (!path) throw coordinationError(new Error("cleanup outside shadow root"));
      rememberShadowParent(dirname(path));
    }
    try {
      unlink(file);
    } catch (error) {
      if (error?.code !== "ENOENT") errors.push(error);
    }
  }

  if (errors.length > 0) {
    const error = new AggregateError(
      [cause, ...errors],
      "spine: shadow write failed and cleanup failed",
    );
    error.code = cause?.code || "ESHADOWCLEANUP";
    throw error;
  }
}

export function writeShadowFile(
  file,
  body,
  access = {},
  { exclusive = false, root, write = writeFileSync, unlink = unlinkSync } = {},
) {
  const dir = dirname(file);
  ensureShadowDir(dir, access);
  return withShadowRoot(root ?? shadowRootForDir(dir), () => {
    const path = scopedFile(file, rotationScope.root);
    if (!path) throw coordinationError(new Error("shadow file outside root scope"));
    writeShadowFileLocked(path, body, access, { exclusive, write, unlink, accessPath: file });
    return file;
  });
}

function writeShadowFileLocked(file, body, access, { exclusive, write, unlink, accessPath }) {
  const dir = dirname(file);
  const parentIdentity = rememberShadowParent(dir);

  // Always stage the body in a private temporary file. Publishing the final
  // name only after the bytes are flushed prevents readers from observing a
  // half-written raw or meta file after a process interruption.
  const target = join(
    dir,
    `.${basename(file)}-${randomBytes(8).toString("hex")}.tmp`,
  );

  let fd = null;
  let created = false;
  let protectedPath = target;

  try {
    fd = openSync(target, "wx", 0o600);
    created = true;

    verifyRotationScope();
    if (parentIdentity && directoryIdentity(dir) !== parentIdentity) {
      retireRotationScope();
      throw coordinationError(new Error("shadow session directory identity changed"));
    }
    // Confirm ACL/mode before any secret bytes are written to the staged file.
    tightenCreatedShadow(target, fd, access);
    rememberShadowParent(dir);
    // Full replacement bytes are a conservative charge, even for overwrites,
    // partial writes and failed cleanup. Metadata/owner/stats are not capacity.
    if (shadowUsage && isPluginShadowName(basename(file))) {
      shadowUsage.bytes += typeof body === "string" ? Buffer.byteLength(body, "utf8") : body.byteLength;
    }
    write(fd, body);
    fsyncSync(fd);

    // The rotation/root lock provides the no-overwrite boundary for exclusive
    // raw files. Refuse a file that appeared after admission; never replace it.
    if (exclusive && existsSync(file)) {
      const error = new Error("shadow file already exists");
      error.code = "EEXIST";
      throw error;
    }
    renameSync(target, file);
    protectedPath = file;
    // staging 临时名一次性且永不复用：发布后其锁表条目已成死重，随 rename 同步
    // 释放，避免每次保存向 lockedFiles 残留一个永不复用的条目。
    releaseLockedFile(target);
    if (basename(file) !== DECISIONS_NAME) {
      decisionRotationAt.delete(rotationScope.root);
      decisionUsageBytes.delete(rotationScope.root);
      decisionUsageMtime.delete(rotationScope.root);
    }

    // Keep the caller's spelling for the permission cache/runner. The opened
    // descriptor and the final path now refer to the same published object.
    tightenCreatedShadow(file, fd, access, { skipRunner: true });

    const opened = fd;
    fd = null;
    closeSync(opened);
    return file;
  } catch (error) {
    const identity = fd !== null ? shadowFileIdentity(protectedPath, fd) : "";
    if (fd !== null) {
      try {
        closeSync(fd);
      } catch {}
    }

    if (created) {
      // Do not unlink through a replacement directory after a failed write.
      let sameParent = false;
      try { sameParent = !parentIdentity || directoryIdentity(dir) === parentIdentity; } catch {}
      if (sameParent && identity && shadowFileIdentity(protectedPath) === identity) {
        discardShadowFiles([protectedPath], error, unlink);
      } else shadowUsage = null;
    }
    throw error;
  }
}

export function writeShadowOwner(dir, access = {}, root) {
  return writeShadowFile(
    join(dir, "owner"),
    String(process.pid),
    access,
    { root },
  );
}

export function shadowMaxBytes(env = process.env) {
  const bytes = Number(env.SPINE_SHADOW_MAX_BYTES);
  if (Number.isFinite(bytes) && bytes > 0) return Math.floor(bytes);
  const mb = Number(env.SPINE_SHADOW_MAX_MB);
  if (Number.isFinite(mb) && mb > 0) return Math.floor(mb * 1024 * 1024);
  return 256 * 1024 * 1024;
}

function readSessionKey(file) {
  const fd = openSync(file, "r");
  try {
    const buf = Buffer.alloc(240);
    const count = readSync(fd, buf, 0, buf.length, 0);
    const line = buf.subarray(0, count).toString("utf8").split("\n")[0] || "";
    return SESSION_MARK.exec(line)?.[1] || "";
  } catch {
    return "";
  } finally {
    closeSync(fd);
  }
}

export function listPluginShadows(dir, {
  readdir = readdirSync,
  stat = statSync,
  onError,
  includeSessionKey = true,
} = {}) {
  let names = [];
  try {
    names = readdir(dir);
  } catch {
    onError?.();
    return [];
  }
  const files = [];
  for (const name of names) {
    if (!isPluginShadowName(name)) continue;
    const path = resolve(dir, name);
    try {
      const info = stat(path);
      if (!info.isFile()) continue;
      files.push({
        name,
        path,
        size: info.size,
        mtimeMs: info.mtimeMs,
        sessionKey: includeSessionKey ? readSessionKey(path) : "",
      });
    } catch { onError?.(); }
  }
  return files;
}

function byAge(left, right) {
  return left.mtimeMs - right.mtimeMs || left.name.localeCompare(right.name);
}

export function listShadowEntries(dir, alive = processAlive, {
  readdir = readdirSync,
  stat = statSync,
  onError,
  includeSessionKey = false,
} = {}) {
  const entries = [];
  let names = [];
  try {
    names = readdir(dir, { withFileTypes: true });
  } catch {
    onError?.();
    return entries;
  }
  for (const entry of names) {
    if (entry.name === ROTATION_LOCK) continue;
    const path = resolve(dir, entry.name);
    if (entry.isFile() && isPluginShadowName(entry.name)) {
      try {
        const info = stat(path);
        entries.push({
          name: entry.name,
          path,
          size: info.size,
          mtimeMs: info.mtimeMs,
          sessionKey: "",
          legacy: true,
          live: false,
        });
      } catch { onError?.(); }
      continue;
    }
    if (!entry.isDirectory()) continue;
    const owner = ownerPid(path);
    let live = owner === null;
    if (owner > 0) {
      try { live = alive(owner) !== false; } catch { live = true; }
    }
    for (const file of listPluginShadows(path, { readdir, stat, onError, includeSessionKey })) {
      // The directory and its owner define deletion authority. Raw tool output
      // is untrusted data and may itself start with a spine-session marker.
      entries.push({ ...file, legacy: false, live, sessionKey: entry.name });
    }
  }
  return entries;
}

// 先删根目录旧文件，再删死会话，最后才删当前会话的旧文件。
// 当前卡片和这次引用的原文路径受保护。删不掉且仍然超限时返回 ok:false。
// Delete legacy root files, then dead sessions, then old files of this session.
// Protect the current card and cited raw paths. If unlink fails and the cap is still exceeded, ok is false.
export function rotateShadow(options) {
  return withShadowRoot(options.dir, () => rotateShadowLocked(options));
}

// Complete backup transaction used by both the synchronous compatibility API
// and the optional root-writer worker. The rotation lock stays held from the
// full reconcile through ACL-protected body publication; callers must not move
// only the scan to a worker and release the lock before the write.
export function saveShadowTransaction({
  shadow,
  file,
  body,
  required = false,
  protectPaths = [],
  sessionKey = "default",
  cap,
  access = {},
  rotationIO = {},
} = {}) {
  ensureShadowDir(shadow, access);
  const dir = sessionDir(shadow, sessionKey);
  ensureShadowDir(dir, access);
  return withShadowRoot(shadow, () => {
    const owner = join(dir, "owner");
    const ownerExisted = existsSync(owner);
    let ownerWritten = false;
    try {
      writeShadowOwner(dir, access, shadow);
      ownerWritten = true;
      const incoming = Buffer.byteLength(body);
      const rotation = rotateShadow({
        ...rotationIO,
        dir: shadow,
        incomingBytes: incoming,
        protectPath: file,
        protectPaths,
        sessionKey,
        cap,
      });
      if (!rotation.ok) {
        if (rotation.reason) {
          const incomplete = rotation.reason === "scan-incomplete";
          const error = Object.assign(new Error(incomplete
            ? "spine: shadow capacity scan is incomplete; backup refused; leaving the span"
            : "spine: shadow capacity measurement is invalid; backup refused; leaving the span"), {
            code: incomplete ? "ESHADOWSCAN" : "ESHADOWMETER",
          });
          if (required) throw error;
          return { ok: false, skipped: true, reason: rotation.reason, rotation };
        }
        if (required) throw new Error("spine: shadow backup is full; leaving the span");
        return { ok: false, skipped: true, reason: "full", rotation };
      }
      writeShadowFile(file, body, access, { root: shadow });
      if (!existsSync(file)) throw new Error("spine: shadow backup was not written");
      return { ok: true, file, rotation };
    } catch (error) {
      if (ownerWritten && !ownerExisted) discardShadowFiles([owner], error);
      throw error;
    }
  });
}

function rotationTime(now) {
  try {
    const value = now();
    return Number.isFinite(value) && value >= 0 ? value : null;
  } catch {
    return null;
  }
}

function rotateShadowLocked({
  incomingBytes, protectPath, protectPaths = [], sessionKey, cap,
  unlink = unlinkSync, alive = processAlive, readdir = readdirSync, stat = statSync,
  now = () => performance.now(),
}) {
  const { root, identity, exclusive } = rotationScope;
  const low = Math.floor(cap * 0.8);
  const oversize = incomingBytes > cap;
  const cached = shadowUsage;
  const observed = exclusive ? rotationTime(now) : null;
  const validTime = observed !== null && (!cached || observed >= cached.lastObservedAt);
  if (exclusive && cached?.cap === cap && validTime && observed >= cached.calibratedAt &&
      observed - cached.calibratedAt < USAGE_MAX_AGE_MS && Number.isSafeInteger(cached.bytes) &&
      Number.isSafeInteger(incomingBytes) && incomingBytes >= 0 && !oversize && cached.bytes + incomingBytes < low) {
    cached.lastObservedAt = observed;
    return { ok: true, deleted: 0, freed: 0, used: cached.bytes, cap, oversize: false, failed: false, estimated: true };
  }
  shadowUsage = null;
  let complete = true;
  const files = listShadowEntries(root, alive, { readdir, stat, onError() { complete = false; } });
  const protect = new Set([protectPath, ...protectPaths].filter(Boolean).map((path) => {
    try { return join(realDirectory(dirname(path)), basename(path)); } catch { return resolve(path); }
  }));
  const current = sanitizeSessionKey(sessionKey);
  let used = files.reduce((sum, file) => sum + file.size, 0);
  const validBytes = [used, incomingBytes, cap].every(Number.isSafeInteger) && used >= 0 && incomingBytes >= 0 && cap > 0;
  // Missing entries make used a lower bound, never evidence of free space.
  // Refuse before deletion as well: a partial scan cannot establish a safe
  // rotation, even when the incoming backup qualifies for the oversize rule.
  if (!complete) {
    return { ok: false, deleted: 0, freed: 0, used, cap, oversize, failed: true, reason: "scan-incomplete" };
  }
  if (!validBytes) {
    return { ok: false, deleted: 0, freed: 0, used, cap, oversize, failed: true, reason: "invalid-measurement" };
  }
  const publishUsage = () => {
    if (!exclusive || !validTime) return;
    const completed = rotationTime(now);
    if (completed === null || completed < observed) return;
    shadowUsage = { root, identity, cap, bytes: used, calibratedAt: completed, lastObservedAt: completed };
  };
  if (!oversize && used + incomingBytes <= cap) {
    publishUsage();
    return { ok: true, deleted: 0, freed: 0, used, cap, oversize: false, failed: false };
  }
  const legacy = [];
  const dead = [];
  const mine = [];
  for (const file of files) {
    if (protect.has(file.path)) continue;
    if (file.live && file.sessionKey !== current) continue;
    if (file.legacy) legacy.push(file);
    else if (file.sessionKey === current) mine.push(file);
    else dead.push(file);
  }
  legacy.sort(byAge);
  dead.sort(byAge);
  mine.sort(byAge);
  let deleted = 0;
  let freed = 0;
  let failed = false;
  for (const file of [...legacy, ...dead, ...mine]) {
    if (!oversize && used + incomingBytes <= low) break;
    try {
      unlink(file.path);
    } catch (error) {
      if (error?.code !== "ENOENT") {
        failed = true;
        break;
      }
    }
    // 文件已被删除（或本就 ENOENT）：同步释放其锁表条目，使锁表随 rotation
    // 收敛而不是只增不减。unlink 失败（文件仍在盘上）时不会走到这里。
    releaseLockedFile(file.path);
    used -= file.size;
    freed += file.size;
    deleted += 1;
    if (file.name.startsWith("raw-")) {
      try {
        unlink(`${file.path}.meta.json`);
      } catch {}
      // meta.json 通常已随之删除；即便 unlink 因占用等失败，释放缓存条目也是
      // 安全方向——下次 tightenShadow 会重新收紧（fail-closed），不会绕过锁。
      releaseLockedFile(`${file.path}.meta.json`);
    }
  }
  const fits = used + incomingBytes <= cap;
  const ok = !failed && (oversize || fits);
  if (ok) publishUsage();
  return {
    ok,
    deleted,
    freed,
    used,
    cap,
    oversize,
    failed,
  };
}
